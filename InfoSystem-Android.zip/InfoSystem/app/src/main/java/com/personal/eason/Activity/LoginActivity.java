package com.personal.eason.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.personal.eason.Entity.Union;
import com.personal.eason.Entity.User;
import com.personal.eason.R;
import com.personal.eason.Util.L;
import com.personal.eason.Util.OkhttpUtils;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {
    public static final String BASE_URL = "http://192.168.43.184:8080/infoSystem/";
    private EditText userIdText,passwordText;
    private Button stu,manger;
    private TextView loginResult;
    private SharedPreferences sps;
    OkHttpClient mclient = new OkHttpClient();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userIdText = findViewById(R.id.login_userId);
        passwordText = findViewById(R.id.login_password);
        stu = findViewById(R.id.StuLogin);
        //manger = findViewById(R.id.MangerLogin);
        loginResult = findViewById(R.id.logoinResult);
        ActivityCollector.addActivity(this);

        sps = getSharedPreferences("user",Context.MODE_PRIVATE);

        stu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String userId = userIdText.getText().toString().trim();
                String password = passwordText.getText().toString().trim();
                if(userId.isEmpty() || password.isEmpty()){
                    loginResult.setText("学号与密码不能为空");
                }else if((userId.length() != 7 || userId.length() != 11)
                        && (password.length() < 6)){
                    loginResult.setText("输入格式错误");
                }else {
                    loginResult.setText("等待验证数据");
                    FormBody formbody = new FormBody.Builder()
                            .add("userId", userId).add("password", password).build();
                    Request request = new Request.Builder()
                            .url(BASE_URL+"login").post(formbody).build();
                    mclient.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            e.printStackTrace();
                            loginResult.setText("获取数据失败");
                        }
                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            final String res = response.body().string();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if(res.contains("user") && res.contains("userId") &&res.contains("name")){
                                        loginResult.setText("登录成功");
                                        Toast.makeText(LoginActivity.this,"登录成功",Toast.LENGTH_SHORT);
                                        Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                                        loadNewUserInfo(res);
                                        startActivity(intent);
                                    }else{
                                        loginResult.setText("登录失败");
                                        Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_SHORT);
                                    }
                                }
                            });
                        }
                    });
                }
            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityCollector.removeActivity(this);
    }
    private void loadNewUserInfo(String userInfo) {
        //L.e(userInfo);
        String userId = userInfo.substring(userInfo.indexOf("userId=")+7,userInfo.indexOf(", name"));
        String name = userInfo.substring(userInfo.indexOf("name=")+5,userInfo.indexOf(", unionId"));
        String phone = userInfo.substring(userInfo.indexOf("phone=")+6,userInfo.indexOf(", college"));
        String sex = userInfo.substring(userInfo.indexOf("sex=")+4,userInfo.indexOf(", phone"));
        String college = userInfo.substring(userInfo.indexOf("college=")+8,userInfo.indexOf(", major"));
        String major = userInfo.substring(userInfo.indexOf("major=")+6,userInfo.indexOf("]"));
        SharedPreferences.Editor editor = sps.edit();
        editor.putString("user_name",name);
        editor.putString("user_id",userId);
        editor.putString("user_phone",phone);
        editor.putString("user_sex",sex);
        editor.putString("user_college",college);
        editor.putString("user_major",major);
        editor.putString("user_union",userInfo.substring(userInfo.indexOf("unionId=")+8,userInfo.indexOf(", departId")));
        editor.putString("user_depart",userInfo.substring(userInfo.indexOf("departId=")+9,userInfo.indexOf(", userTypeId")));
        editor.putString("user_type",userInfo.substring(userInfo.indexOf("userTypeId=")+11,userInfo.indexOf(", sex")));
        editor.commit();
    }
    //test for Okhttp
    public void doGet(View view){
        OkHttpClient mclient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASE_URL+"login?userId=15211110143&password=123456")
                .build();
        executeRequest(request);
    }
    public void doPost(View view){
        FormBody formbody = new FormBody.Builder()
                .add("userId", "15211110143")
                .add("password", "123456")
                .build();
        Request request = new Request.Builder()
                .url(BASE_URL+"login")
                .post(formbody)
                .build();
        executeRequest(request);
    }
    public void doPostString(View view){
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), "{userId:15211110143,password:123456}");
        Request request = new Request.Builder()
                .url(BASE_URL+"postString")
                .post(requestBody)
                .build();
        executeRequest(request);
    }
    private void executeRequest(Request request) {
        mclient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                L.e("onFailure:"+e.getMessage());
                e.printStackTrace();
                loginResult.setText("failed");
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                L.e("onResponse:");
                final String res = response.body().string();
                L.e(res);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loginResult.setText(res);
                    }
                });
            }
        });
    }
}
