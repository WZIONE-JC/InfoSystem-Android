package com.personal.eason.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.personal.eason.Entity.Depart;
import com.personal.eason.Entity.Union;
import com.personal.eason.R;

import java.util.List;

/**
 * Created by HSDN on 2018/2/13.
 */

public class DepartAdapter extends RecyclerView.Adapter<DepartAdapter.ViewHolder>{

    private List<Depart> mDepartList;

    // 利用接口 -> 给RecyclerView设置点击事件
    private ItemClickListener mItemClickListener ;
    public interface ItemClickListener {
        public void onItemClick(int position) ;
    }
    public void setOnItemClickListener(ItemClickListener itemClickListener){
        this.mItemClickListener = itemClickListener ;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView id,name,unionId,teacherId,presidentId,ministerId,memberSum,featureActivities,remark;
        LinearLayout depart_background;

        public ViewHolder(View view){
            super(view);
            id = view.findViewById(R.id.departId);
            name = view.findViewById(R.id.departName);
        }
    }

    public DepartAdapter(List<Depart> departList){
        mDepartList = departList;
    }

    @Override
    public DepartAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.depart_item,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(DepartAdapter.ViewHolder holder, final int position) {
        Depart depart = mDepartList.get(position);
        holder.id.setText(depart.getId()+"");
        holder.name.setText(depart.getName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //通过接口名调用方法
                mItemClickListener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDepartList.size();
    }
}
