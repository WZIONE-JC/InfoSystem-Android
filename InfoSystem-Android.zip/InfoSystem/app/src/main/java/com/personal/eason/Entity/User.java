package com.personal.eason.Entity;

import java.util.Date;

/**
 * Created by Administrator on 2019/4/13 0013.
 */
public class User {
    private String userId;
    private String name;
    private String password;
    private Integer unionId;
    private Integer departId;
    private Integer userTypeId;
    private Integer sex;
    private String phone;
    private String major;
    private String college;
    private String remark;
    private Date createDateTime;

    public User() {
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public Integer getUnionId() {
        return unionId;
    }

    public Integer getDepartId() {
        return departId;
    }

    public Integer getUserTypeId() {
        return userTypeId;
    }

    public Integer getSex() {
        return sex;
    }

    public String getPhone() {
        return phone;
    }

    public String getMajor() {
        return major;
    }

    public String getCollege() {
        return college;
    }

    public String getRemark() {
        return remark;
    }

    public Date getCreateDateTime() {
        return createDateTime;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUnionId(Integer unionId) {
        this.unionId = unionId;
    }

    public void setDepartId(Integer departId) {
        this.departId = departId;
    }

    public void setUserTypeId(Integer userTypeId) {
        this.userTypeId = userTypeId;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setCreateDateTime(Date createDateTime) {
        this.createDateTime = createDateTime;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId='" + userId + '\'' +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", unionId=" + unionId +
                ", departId=" + departId +
                ", userTypeId=" + userTypeId +
                ", sex=" + sex +
                ", phone='" + phone + '\'' +
                ", major='" + major + '\'' +
                ", college='" + college + '\'' +
                ", remark='" + remark + '\'' +
                ", createDateTime=" + createDateTime +
                '}';
    }
}
