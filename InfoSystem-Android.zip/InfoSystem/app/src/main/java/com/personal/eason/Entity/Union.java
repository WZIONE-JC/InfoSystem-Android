package com.personal.eason.Entity;

/**
 * Created by Administrator on 2019/4/17 0017.
 */

public class Union {
    private Integer id;
    private String name;
    private Integer belongId;//组织所属
    private Integer departSum;//部门数量
    private String ministerName;//组织总负责人
    private String remark;

    public Union() {
    }

    public Union(Integer id, String name, Integer belongId) {
        this.id = id;
        this.name = name;
        this.belongId = belongId;
    }

    public Union(Integer id, String name, Integer belongId, Integer departSum, String ministerName) {
        this.id = id;
        this.name = name;
        this.belongId = belongId;
        this.departSum = departSum;
        this.ministerName = ministerName;
    }

    public Union(Integer id, String name, Integer belongId, Integer departSum, String ministerName, String remark) {
        this.id = id;
        this.name = name;
        this.belongId = belongId;
        this.departSum = departSum;
        this.ministerName = ministerName;
        this.remark = remark;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getBelongId() {
        return belongId;
    }

    public Integer getDepartSum() {
        return departSum;
    }

    public String getMinisterName() {
        return ministerName;
    }

    public String getRemark() {
        return remark;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBelongId(Integer belongId) {
        this.belongId = belongId;
    }

    public void setDepartSum(Integer departSum) {
        this.departSum = departSum;
    }

    public void setMinisterName(String ministerName) {
        this.ministerName = ministerName;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "Union{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", belongId=" + belongId +
                ", departSum='" + departSum + '\'' +
                ", ministerName='" + ministerName + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
