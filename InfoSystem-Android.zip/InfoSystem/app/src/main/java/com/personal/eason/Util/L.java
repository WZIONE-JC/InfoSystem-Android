package com.personal.eason.Util;

import android.util.Log;

/**
 * Created by Administrator on 2019/4/13 0013.
 */

public class L {
    private static final String TAG = "fyc1997";
    private static boolean debug = true;

    public static void e(String msg){
        if(debug)
            Log.e(TAG, msg);
    }
}
