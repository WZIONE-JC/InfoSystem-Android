package com.personal.eason.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.personal.eason.Entity.Depart;
import com.personal.eason.Entity.User;
import com.personal.eason.R;

import java.util.List;

/**
 * Created by HSDN on 2018/2/13.
 */

public class MinisterAdapter extends RecyclerView.Adapter<MinisterAdapter.ViewHolder>{

    private List<User> mMinisterList;

    // 利用接口 -> 给RecyclerView设置点击事件
    private ItemClickListener mItemClickListener ;
    public interface ItemClickListener {
        public void onItemClick(int position) ;
    }
    public void setOnItemClickListener(ItemClickListener itemClickListener){
        this.mItemClickListener = itemClickListener ;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView userId,name,sex,type,college,major;
        LinearLayout depart_background;

        public ViewHolder(View view){
            super(view);
            userId = view.findViewById(R.id.ministerId);
            name = view.findViewById(R.id.ministerName);
            sex = view.findViewById(R.id.ministerSex);
            type = view.findViewById(R.id.ministerType);
            college = view.findViewById(R.id.ministerCollege);
            major = view.findViewById(R.id.ministerMajor);
        }
    }

    public MinisterAdapter(List<User> ministerList){
        mMinisterList = ministerList;
    }

    @Override
    public MinisterAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.minister_item,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(MinisterAdapter.ViewHolder holder, final int position) {
        User user = mMinisterList.get(position);
        holder.userId.setText(user.getUserId()+"");
        holder.name.setText(user.getName());
        String sex = "女";
        if(user.getSex()==1){ sex = "男"; }
        holder.sex.setText(sex);
        String userType = "普通用户";
        if(user.getUserTypeId()==2){ userType="干事"; }
        else if(user.getUserTypeId()==3){ userType="部长"; }
        else if(user.getUserTypeId()==4 || user.getUserTypeId()==6){ userType="部长"; }
        else if(user.getUserTypeId()==5){ userType="指导老师"; }
        holder.type.setText(userType);
        holder.college.setText(user.getCollege());
        holder.major.setText(user.getMajor());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //通过接口名调用方法
                mItemClickListener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mMinisterList.size();
    }
}
