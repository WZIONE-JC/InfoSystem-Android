package com.personal.eason.Adapter;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.personal.eason.Activity.MainActivity;
import com.personal.eason.Activity.UnionActivity;
import com.personal.eason.Entity.Union;
import com.personal.eason.R;

import java.util.List;

import static android.support.v4.content.ContextCompat.startActivity;

/**
 * Created by HSDN on 2018/2/13.
 */

public class UnionAdapter extends RecyclerView.Adapter<UnionAdapter.ViewHolder>{

    private List<Union> mUnionList;

    // 利用接口 -> 给RecyclerView设置点击事件
    private ItemClickListener mItemClickListener ;
    public interface ItemClickListener {
        public void onItemClick(int position) ;
    }
    public void setOnItemClickListener(ItemClickListener itemClickListener){
        this.mItemClickListener = itemClickListener ;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView id,name,belong,minister;
        LinearLayout union_background;

        public ViewHolder(View view){
            super(view);
            id = view.findViewById(R.id.unionId);
            name = view.findViewById(R.id.unionName);
            belong = view.findViewById(R.id.unionBelong);
            minister = view.findViewById(R.id.unionMinister);
        }
    }

    public UnionAdapter(List<Union> unionList){
        mUnionList = unionList;
    }

    @Override
    public UnionAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.union_item,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(UnionAdapter.ViewHolder holder, final int position) {
        Union union = mUnionList.get(position);
        holder.id.setText(union.getId()+"");
        holder.name.setText(union.getName());
        String belongName = "";
        if(union.getBelongId() == 1){
            belongName = "校团委";
        }else if(union.getBelongId() == 2){
            belongName = "学区";
        }else if(union.getBelongId() == 3){
            belongName = "学院";
        }else{
            belongName = "温州大学";
        }
        holder.belong.setText(belongName);
        holder.minister.setText(union.getMinisterName());
        //holder.union_background.setBackgroundResource(union.getId());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //通过接口名调用方法
                mItemClickListener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mUnionList.size();
    }
}
