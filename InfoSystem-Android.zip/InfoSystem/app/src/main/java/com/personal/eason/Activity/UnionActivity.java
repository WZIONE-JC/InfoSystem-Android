package com.personal.eason.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.personal.eason.Adapter.DepartAdapter;
import com.personal.eason.Adapter.MinisterAdapter;
import com.personal.eason.Entity.Depart;
import com.personal.eason.Entity.Union;
import com.personal.eason.R;
import com.personal.eason.Util.L;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import static com.personal.eason.Activity.LoginActivity.BASE_URL;

public class UnionActivity extends AppCompatActivity {

    private List<Depart> departList = new ArrayList<>();
    private RecyclerView recyclerView;
    private DepartAdapter adapter = new DepartAdapter(departList);;
    private LinearLayout update_union_info,union_info_item,union_info_edit_item;
    private TextView union_info_name,union_info_id,union_info_belong,union_info_departSum,union_info_remark;
    private Button union_info_edit,union_edit_cancel,union_edit_finish;
    private SharedPreferences sps;
    private TextView union_name_edit,union_id_edit,union_belong_edit;
    private EditText union_departSum_edit,union_remark_edit;
    OkHttpClient mclient = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_union);

        Toolbar toolbar = (Toolbar) findViewById(R.id.union_toolbar);
        setSupportActionBar(toolbar);

        union_info_item = findViewById(R.id.union_info_item);
        union_info_edit_item = findViewById(R.id.union_info_edit_item);
        union_info_edit_item.setVisibility(View.GONE);

        recyclerView = findViewById(R.id.depart_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(UnionActivity.this);
        recyclerView.setLayoutManager(layoutManager);

        Intent intent = getIntent();
        String union = intent.getStringExtra("union");
        //L.e(union);
        loadUnionInfo(union);
    }

    private void loadUnionInfo(String str) {
        //L.e(str.toString());
        str = str.replace("Union","").replace("{","{\"").replace("=","\":")
            .replace("\'","\"").replace(", ",",\"");
        JSONObject json = JSONObject.parseObject(str);
        final Union union = JSONObject.toJavaObject(json,Union.class);
        //L.e(union.getName());
        //L.e(String.valueOf(union.getId()));
        String belongName = "温州大学";
        if(union.getBelongId() == 1){
            belongName = "校团委";
        }else if(union.getBelongId() == 2){
            belongName = "学区";
        }else if(union.getBelongId() == 3){
            belongName = "学院";
        }
        union_info_name = findViewById(R.id.union_info_name);
        union_info_id = findViewById(R.id.union_info_id);
        union_info_belong = findViewById(R.id.union_info_belong);
        union_info_departSum = findViewById(R.id.union_info_departSum);
        union_info_remark = findViewById(R.id.union_info_remark);

        union_info_name.setText(union.getName());
        union_info_id.setText(String.valueOf(union.getId()));
        union_info_belong.setText(belongName);
        union_info_departSum.setText(String.valueOf(union.getDepartSum()));
        union_info_remark.setText(union.getRemark().toString());

        update_union_info = findViewById(R.id.update_union_info);
        sps = getSharedPreferences("user", Context.MODE_PRIVATE);
        String userType = sps.getString("user_type","");
        if(userType.equals("5") || userType.equals("7")){
            update_union_info.setVisibility(View.VISIBLE);
            union_info_edit = findViewById(R.id.union_info_edit);
            union_info_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    union_info_item.setVisibility(View.GONE);
                    union_info_edit_item.setVisibility(View.VISIBLE);
                    loadUnionEdit(union);
                    union_edit_finish = findViewById(R.id.union_edit_finish);
                    union_edit_cancel = findViewById(R.id.union_edit_cancel);
                    union_edit_finish.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    });
                    union_edit_cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            union_info_item.setVisibility(View.VISIBLE);
                            union_info_edit_item.setVisibility(View.GONE);
                        }
                    });
                }
            });
        }
        initDeparts(union.getId()+"");
    }

    private void initDeparts(String unionId) {
        clearDepartList();
        FormBody formbody = new FormBody.Builder()
                .add("unionId",unionId).build();
        Request request = new Request.Builder()
                .url(BASE_URL + "departList")
                .post(formbody)
                .build();
        mclient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //L.e("onFailure:" + e.getMessage());
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //L.e("onResponse:");
                final String res = response.body().string();
                //L.e(res);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String str = res.replace("},", "}},").replace("[", "").replace("]", "");
                        //L.e(str);
                        String[] departs = str.split("\\}\\,");
                        if(departs.length != 0){
                            for (int i = 0; i < departs.length; i++) {
                                //L.e(departs[i]);
                                JSONObject json = JSONObject.parseObject(departs[i]);
                                //L.e(json.toString());
                                Depart depart = JSONObject.toJavaObject(json, Depart.class);
                                //L.e(depart.toString());
                                departList.add(depart);
                            }
                            adapter.notifyDataSetChanged();
                            recyclerView.setAdapter(adapter);

                            // 设置数据后就要给RecyclerView设置点击事件
                            adapter.setOnItemClickListener(new DepartAdapter.ItemClickListener() {
                                @Override
                                public void onItemClick(int position) {
                                    Intent intent = new Intent(UnionActivity.this,DepartActivity.class);
                                    intent.putExtra("depart",departList.get(position).toString());
                                    startActivity(intent);
                                }
                            });
                        }else{
                            clearDepartList();
                        }
                    }
                });
            }
        });
    }

    private void loadUnionEdit(Union union){
        union_name_edit = findViewById(R.id.union_name_edit);
        union_id_edit = findViewById(R.id.union_id_edit);
        union_belong_edit = findViewById(R.id.union_belong_edit);
        union_departSum_edit = findViewById(R.id.union_departSum_edit);
        union_remark_edit = findViewById(R.id.union_remark_edit);

        String belongName = "温州大学";
        if(union.getBelongId() == 1){
            belongName = "校团委";
        }else if(union.getBelongId() == 2){
            belongName = "学区";
        }else if(union.getBelongId() == 3){
            belongName = "学院";
        }
        union_name_edit.setText(union.getName());
        union_id_edit.setText(String.valueOf(union.getId()));
        union_belong_edit.setText(belongName);
        union_departSum_edit.setText(String.valueOf(union.getDepartSum()));
        union_remark_edit.setText(union.getRemark().toString());
    }

    private void clearDepartList() {
        departList.clear();
        adapter.notifyDataSetChanged();
        recyclerView.removeAllViews();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_union, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_union_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
