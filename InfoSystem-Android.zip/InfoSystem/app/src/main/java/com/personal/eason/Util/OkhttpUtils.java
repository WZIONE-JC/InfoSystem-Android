package com.personal.eason.Util;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

/**
 * Created by Administrator on 2019/4/13 0013.
 */
public class OkhttpUtils {

    private static OkHttpClient mclient;

    //GET
    public static void doGet(String address, Callback callback){
        mclient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(address)
                .build();
        mclient.newCall(request).enqueue(callback);
    }

    //POST
    public static void doPost(String address, RequestBody formbody, Callback callback){
        mclient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(address)
                .post(formbody)
                .build();
        mclient.newCall(request).enqueue(callback);
    }
}
