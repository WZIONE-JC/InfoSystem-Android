package com.personal.eason.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.personal.eason.Adapter.DepartAdapter;
import com.personal.eason.Adapter.MinisterAdapter;
import com.personal.eason.Entity.Depart;
import com.personal.eason.Entity.Union;
import com.personal.eason.Entity.User;
import com.personal.eason.R;
import com.personal.eason.Util.L;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.personal.eason.Activity.LoginActivity.BASE_URL;

public class DepartActivity extends AppCompatActivity {

    private List<User> ministerList = new ArrayList<>();
    private RecyclerView recyclerView;
    private MinisterAdapter adapter = new MinisterAdapter(ministerList);
    private LinearLayout update_depart_info,depart_info_item,depart_info_edit_item,minister_info_edit_item;
    private TextView depart_info_name,depart_info_id,depart_info_union,depart_info_teacher,depart_info_president,depart_info_minister,depart_info_remark;
    private Button depart_info_edit,depart_edit_finish,depart_edit_cancel;
    private Button minister_edit_cancel,minister_edit_finish;
    private TextView depart_name_edit,depart_id_edit;
    private TextView minister_name_edit,minister_id_edit,minister_sex_edit,minister_college_edit,minister_major_edit;
    private EditText depart_union_edit,depart_teacher_edit,depart_president_edit,depart_minister_edit,depart_remark_edit;
    private EditText minister_union_edit,minister_depart_edit,minister_type_edit;
    private SharedPreferences sps;
    OkHttpClient mclient = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depart);

        Toolbar toolbar = (Toolbar) findViewById(R.id.depart_toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.minister_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(DepartActivity.this);
        recyclerView.setLayoutManager(layoutManager);

        depart_info_item = findViewById(R.id.depart_info_item);
        depart_info_edit_item = findViewById(R.id.depart_info_edit_item);
        depart_info_item.setVisibility(View.VISIBLE);
        depart_info_edit_item.setVisibility(View.GONE);

        Intent intent = getIntent();
        String depart = intent.getStringExtra("depart");
        //L.e(depart);
        loadDepartInfo(depart);
    }

    private void loadDepartInfo(String str) {
        //L.e(str.toString());
        str = str.replace("Depart","").replace("{","{\"").replace("=","\":")
            .replace("\'","\"").replace(", ",",\"");
        JSONObject json = JSONObject.parseObject(str);
        final Depart depart = JSONObject.toJavaObject(json,Depart.class);

        depart_info_name = findViewById(R.id.depart_info_name);
        depart_info_id = findViewById(R.id.depart_info_id);
        depart_info_union = findViewById(R.id.depart_info_union);
        depart_info_teacher = findViewById(R.id.depart_info_teacher);
        depart_info_minister = findViewById(R.id.depart_info_minister);
        depart_info_president = findViewById(R.id.depart_info_president);
        depart_info_remark = findViewById(R.id.depart_info_remark);

        depart_info_name.setText(depart.getName());
        depart_info_id.setText(String.valueOf(depart.getId()));
        depart_info_union.setText(String.valueOf(depart.getUnionId()));
        depart_info_teacher.setText(String.valueOf(depart.getTeacherId()));
        depart_info_minister.setText(String.valueOf(depart.getMinisterId()));
        depart_info_president.setText(String.valueOf(depart.getPresidentId()));
        depart_info_remark.setText(depart.getRemark().toString());

        update_depart_info = findViewById(R.id.update_depart_info);
        sps = getSharedPreferences("user", Context.MODE_PRIVATE);
        String user_depart = sps.getString("user_depart","");
        if(user_depart.equals(String.valueOf(depart.getId()))){
            update_depart_info.setVisibility(View.VISIBLE);
            depart_info_edit = findViewById(R.id.depart_info_edit);
            depart_info_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    depart_info_item.setVisibility(View.GONE);
                    depart_info_edit_item.setVisibility(View.VISIBLE);
                    loadDepartEdit(depart);
                    depart_edit_finish = findViewById(R.id.depart_edit_finish);
                    depart_edit_cancel = findViewById(R.id.depart_edit_cancel);
                    depart_edit_finish.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    });
                    depart_edit_cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            depart_info_edit_item.setVisibility(View.GONE);
                            depart_info_item.setVisibility(View.VISIBLE);
                        }
                    });
                }
            });
        }
        initMinisters(depart.getId()+"");
    }

    private void loadDepartEdit(Depart depart){
        depart_name_edit = findViewById(R.id.depart_name_edit);
        depart_id_edit = findViewById(R.id.depart_id_edit);
        depart_union_edit = findViewById(R.id.depart_union_edit);
        depart_teacher_edit = findViewById(R.id.depart_teacher_edit);
        depart_president_edit = findViewById(R.id.depart_president_edit);
        depart_minister_edit = findViewById(R.id.depart_minister_edit);
        depart_remark_edit = findViewById(R.id.depart_remark_edit);

        depart_name_edit.setText(depart.getName());
        depart_id_edit.setText(String.valueOf(depart.getId()));
        depart_union_edit.setText(String.valueOf(depart.getUnionId()));
        depart_teacher_edit.setText(String.valueOf(depart.getTeacherId()));
        depart_minister_edit.setText(String.valueOf(depart.getMinisterId()));
        depart_president_edit.setText(String.valueOf(depart.getPresidentId()));
        depart_remark_edit.setText(depart.getRemark().toString());
    }

    private void initMinisters(final String departId) {
        clearMinisterList();
        FormBody formbody = new FormBody.Builder()
                .add("departId",departId).build();
        Request request = new Request.Builder()
                .url(BASE_URL + "ministerList")
                .post(formbody)
                .build();
        mclient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //L.e("onFailure:" + e.getMessage());
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //L.e("onResponse:");
                final String res = response.body().string();
                //L.e(res);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String str = res.replace("},", "}},").replace("[", "").replace("]", "");
                        //L.e(str);
                        String[] users = str.split("\\}\\,");
                        if(users.length > 0){
                            for (int i = 0; i < users.length; i++) {
                                //L.e(users[i]);
                                JSONObject json = JSONObject.parseObject(users[i]);
                                //L.e(json.toString());
                                User user = JSONObject.toJavaObject(json, User.class);
                                //L.e(depart.toString());
                                ministerList.add(user);
                            }
                            adapter.notifyDataSetChanged();
                            recyclerView.setAdapter(adapter);

                            // 设置数据后就要给RecyclerView设置点击事件
                            adapter.setOnItemClickListener(new MinisterAdapter.ItemClickListener() {
                                @Override
                                public void onItemClick(final int position) {
                                    sps = getSharedPreferences("user", Context.MODE_PRIVATE);
                                    String user_depart = sps.getString("user_depart","");
                                    String user_type = sps.getString("user_type","1");
                                    if(user_depart.equals(departId) && (user_type.equals("3") || user_type.equals("6"))){
                                        minister_info_edit_item = findViewById(R.id.minister_info_edit_item);
                                        depart_info_item.setVisibility(View.GONE);
                                        minister_info_edit_item.setVisibility(View.VISIBLE);
                                        minister_edit_cancel = findViewById(R.id.minister_edit_cancel);
                                        minister_edit_finish = findViewById(R.id.minister_edit_finish);
                                        //L.e(ministerList.get(position).toString());
                                        loadMinisterInfo(ministerList.get(position));
                                        minister_edit_cancel.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                minister_info_edit_item.setVisibility(View.GONE);
                                                depart_info_item.setVisibility(View.VISIBLE);
                                            }
                                        });
                                        minister_edit_finish.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {

                                            }
                                        });
                                    }
                                }
                            });
                        }else{
                            clearMinisterList();
                        }
                    }
                });
            }
        });
    }

    private void loadMinisterInfo(User user){
        minister_name_edit = findViewById(R.id.minister_name_edit);
        minister_id_edit = findViewById(R.id.minister_id_edit);
        minister_sex_edit = findViewById(R.id.minister_sex_edit);
        minister_college_edit = findViewById(R.id.minister_college_edit);
        minister_major_edit = findViewById(R.id.minister_major_edit);
        minister_union_edit = findViewById(R.id.minister_union_edit);
        minister_depart_edit = findViewById(R.id.minister_depart_edit);
        minister_type_edit = findViewById(R.id.minister_type_edit);

        minister_name_edit.setText(user.getName());
        minister_id_edit.setText(user.getUserId());
        String sex = "男";
        if(user.getSex()==2){
            sex = "女";
        }
        minister_sex_edit.setText(sex);
        minister_college_edit.setText(user.getCollege());
        minister_major_edit.setText(user.getMajor());
        minister_union_edit.setText(user.getUnionId()+"");
        minister_depart_edit.setText(user.getDepartId()+"");
        minister_type_edit.setText(user.getUserTypeId()+"");
    }

    private void clearMinisterList() {
        ministerList.clear();
        adapter.notifyDataSetChanged();
        recyclerView.removeAllViews();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_depart, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_depart_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
