package com.personal.eason.Activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.personal.eason.Adapter.UnionAdapter;
import com.personal.eason.Entity.Union;
import com.personal.eason.Entity.User;
import com.personal.eason.R;
import com.personal.eason.Util.L;

import net.sf.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.personal.eason.Activity.LoginActivity.BASE_URL;

public class MainActivity extends AppCompatActivity {
    OkHttpClient mclient = new OkHttpClient();
    private List<Union> unionList = new ArrayList<>();
    private RecyclerView recyclerView;
    private UnionAdapter adapter = new UnionAdapter(unionList);;
    private LinearLayout user_info,user_info_edit;
    private Button user_edit,user_edit_cancel,user_edit_finish;
    private String userInfo;
    private SharedPreferences sps;
    private TextView user_name,user_id,user_phone,user_sex,user_age,user_constellation,user_college,user_major,user_union,user_depart,user_type;
    private TextView user_name_edit,user_id_edit;
    private EditText user_phone_edit,user_sex_edit,user_college_edit,user_major_edit,user_union_edit,user_depart_edit,user_type_edit;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    user_info.setVisibility(View.GONE);
                    user_info_edit.setVisibility(View.GONE);
                    initUnions();
                    return true;
                case R.id.navigation_notifications:
                    user_info.setVisibility(View.GONE);
                    user_info_edit.setVisibility(View.GONE);
                    clearUnionList();
                    return true;
                case R.id.navigation_dashboard:
                    user_info_edit.setVisibility(View.GONE);
                    user_info.setVisibility(View.VISIBLE);
                    clearUnionList();
                    return true;
            }
            return false;
        }
    };

    private void clearUnionList() {
        unionList.clear();
        adapter.notifyDataSetChanged();
        recyclerView.removeAllViews();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCollector.finishAll();
        ActivityCollector.addActivity(this);

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        sps = getSharedPreferences("user",Context.MODE_PRIVATE);
        loadUser();

        user_info = findViewById(R.id.user_info);
        user_info_edit = findViewById(R.id.user_info_edit);
        user_info.setVisibility(View.GONE);
        user_info_edit.setVisibility(View.GONE);

        user_edit = findViewById(R.id.user_edit);
        user_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_info.setVisibility(View.GONE);
                user_info_edit.setVisibility(View.VISIBLE);
                loadUserEdit();
            }
        });
        user_edit_cancel = findViewById(R.id.user_edit_cancel);
        user_edit_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_info_edit.setVisibility(View.GONE);
                user_info.setVisibility(View.VISIBLE);
            }
        });
        user_edit_finish = findViewById(R.id.user_edit_finish);
        user_edit_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeUserInfo();
                user_info_edit.setVisibility(View.GONE);
                user_info.setVisibility(View.VISIBLE);
            }
        });

        recyclerView = findViewById(R.id.union_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutManager);
        initUnions();
    }

    private void loadUserEdit() {
        user_name_edit = findViewById(R.id.user_name_edit);
        //L.e("123:"+sps.getString("user_name",""));
        user_name_edit.setText(sps.getString("user_name",""));
        user_id_edit = findViewById(R.id.user_id_edit);
        user_id_edit.setText(sps.getString("user_id",""));
        user_phone_edit = findViewById(R.id.user_phone_edit);
        user_phone_edit.setText(sps.getString("user_phone",""));
        user_sex_edit = findViewById(R.id.user_sex_edit);
        user_sex_edit.setText((sps.getString("user_sex","").equals("1") ||
                sps.getString("user_sex","").equals("男"))?"男":"女");
        user_college_edit = findViewById(R.id.user_college_edit);
        user_college_edit.setText(sps.getString("user_college",""));
        user_major_edit = findViewById(R.id.user_major_edit);
        user_major_edit.setText(sps.getString("user_major",""));
        user_union_edit = findViewById(R.id.user_org_edit);
        user_union_edit.setText(sps.getString("user_union",""));
        user_depart_edit = findViewById(R.id.user_depart_edit);
        user_depart_edit.setText(sps.getString("user_depart",""));
        user_type_edit = findViewById(R.id.user_type_edit);
        user_type_edit.setText(sps.getString("user_type",""));
    }
    private void loadUser() {
        user_name = findViewById(R.id.user_name);
        //L.e("123:"+sps.getString("user_name",""));
        user_name.setText(sps.getString("user_name",""));
        user_id = findViewById(R.id.user_id);
        user_id.setText(sps.getString("user_id",""));
        user_phone = findViewById(R.id.user_phone);
        user_phone.setText(sps.getString("user_phone",""));
        user_sex = findViewById(R.id.user_sex);
        user_sex.setText((sps.getString("user_sex","").equals("1") ||
                sps.getString("user_sex","").equals("男"))?"男":"女");
        user_college = findViewById(R.id.user_college);
        user_college.setText(sps.getString("user_college",""));
        user_major = findViewById(R.id.user_major);
        user_major.setText(sps.getString("user_major",""));
        user_union = findViewById(R.id.org_name);
        user_union.setText(sps.getString("user_union",""));
        user_depart = findViewById(R.id.org_depart);
        user_depart.setText(sps.getString("user_depart",""));
        user_type = findViewById(R.id.org_minister);
        user_type.setText(sps.getString("user_type",""));
    }
    private void updateUserInfo(String userId,String sex,String college,String major,String phone,String union,String depart,String type) {
        SharedPreferences.Editor editor = sps.edit();
        editor.putString("user_id",userId);
        editor.putString("user_phone",phone);
        editor.putString("user_sex",sex);
        editor.putString("user_college",college);
        editor.putString("user_major",major);
        editor.putString("user_union",union);
        editor.putString("user_depart",depart);
        editor.putString("user_type",type);
        editor.commit();
        loadUser();
    }

    private void initUnions(){
        unionList.clear();
        Request request = new Request.Builder()
                .url(BASE_URL+"unionList")
                .build();
        mclient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                L.e("onFailure:"+e.getMessage());
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //SL.e("onResponse:");
                final String res = response.body().string();
                //L.e(res);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String str = res.replace("},","}},").replace("[","").replace("]","");
                        //L.e(str);
                        String[] unions = str.split("\\}\\,");
                        for(int i=0;i<unions.length;i++){
                            //L.e(unions[i]);
                            JSONObject json = JSONObject.parseObject(unions[i]);
                            //L.e(json.toString());
                            Union union = JSONObject.toJavaObject(json,Union.class);
                            //L.e(union.toString());
                            unionList.add(union);
                        }
                        adapter.notifyDataSetChanged();
                        recyclerView.setAdapter(adapter);

                        // 设置数据后就要给RecyclerView设置点击事件
                        adapter.setOnItemClickListener(new UnionAdapter.ItemClickListener() {
                            @Override
                            public void onItemClick(int position) {
                                // 这里本来是跳转页面 ，我们就在这里直接让其弹toast来演示
                                Intent intent = new Intent(MainActivity.this,UnionActivity.class);
                                intent.putExtra("union",unionList.get(position).toString());
                                startActivity(intent);
                            }
                        });
                    }
                });
            }
        });
    }
    public void changeUserInfo(){
        user_id_edit = findViewById(R.id.user_id_edit);
        final String userId = user_id_edit.getText().toString();
        user_sex_edit = findViewById(R.id.user_sex_edit);
        final String userSex = user_sex_edit.getText().toString();
        user_college_edit = findViewById(R.id.user_college_edit);
        final String userCollege = user_college_edit.getText().toString();
        user_major_edit = findViewById(R.id.user_major_edit);
        final String userMajor = user_major_edit.getText().toString();
        user_phone_edit = findViewById(R.id.user_phone_edit);
        final String userPone = user_phone_edit.getText().toString();
        user_union_edit = findViewById(R.id.user_org_edit);
        final String userUnion = user_union_edit.getText().toString();
        user_depart_edit = findViewById(R.id.user_depart_edit);
        final String userDepart = user_depart_edit.getText().toString();
        user_type_edit = findViewById(R.id.user_type_edit);
        final String userType = user_type_edit.getText().toString();
        FormBody formbody = new FormBody.Builder()
                .add("userId",userId)
                .add("sex", userSex)
                .add("college", userCollege)
                .add("major", userMajor)
                .add("phone", userPone)
                .add("union", userUnion)
                .add("depart", userDepart)
                .add("type", userType)
                .build();
        Request request = new Request.Builder()
                .url(BASE_URL+"updateUserInfo")
                .post(formbody)
                .build();
        mclient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                L.e("onFailure:"+e.getMessage());
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                L.e("onResponse:");
                final String res = response.body().string();
                L.e(res);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(res.equals("update success")){
                            updateUserInfo(userId,userSex,userCollege,userMajor,userPone,userUnion,userDepart,userType);
                        }
                    }
                });
            }
        });
    }
}
