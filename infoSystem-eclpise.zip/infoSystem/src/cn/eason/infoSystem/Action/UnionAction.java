package cn.eason.infoSystem.Action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import cn.eason.infoSystem.Util.DBUtil;
import net.sf.json.JSONArray;

public class UnionAction {
	
	private String unionId;
	
	public String unionList() throws IOException {
		//��ѯ���ݿ�
		JSONArray json = DBUtil.selectUnionList();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		writer.write(json.toString());
		writer.flush();
		return null;
	}
	
	public String departList() throws IOException {
		//��ѯ���ݿ�
		JSONArray json = DBUtil.selectDepartList(unionId);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		writer.write(json.toString());
		writer.flush();
		return null;
	}

	public String getUnionId() {
		return unionId;
	}

	public void setUnionId(String unionId) {
		this.unionId = unionId;
	}
	
	
}
