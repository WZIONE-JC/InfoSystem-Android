package cn.eason.infoSystem.Action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import cn.eason.infoSystem.Entity.Union;
import cn.eason.infoSystem.Entity.User;
import cn.eason.infoSystem.Util.DBUtil;
import net.sf.json.JSONArray;

public class UserAction extends ActionSupport{
	
	private String userId;
	private String password;
	private String sex,college,major,phone,union,depart,type;
	
	public String postString() throws IOException {
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setCharacterEncoding("utf-8");
		ServletInputStream is = request.getInputStream();
		StringBuilder sb = new StringBuilder();
		int len = 0;
		byte[] buf = new byte[1024];
		while((len = is.read(buf)) != -1) {
			sb.append(new String(buf,0,len));
		}
		System.out.println(sb.toString());
		return null;
	}
	
	public String login() throws IOException {
		System.out.println(userId+","+password);	
		//��ѯ���ݿ�
		User user = DBUtil.selectUser("select * from t_user where userId='"+userId+"' and password='"+password+"';");
		System.out.println(user.toString());
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		if(user.getName().equals("null") || user.getName().equals("") || user.getName().isEmpty()) {
			writer.write("login failed");
		}else {
			writer.write(user.toString());
		}
		writer.flush();
		return null;
	}
	
	public String updateUserInfo() throws IOException {
		System.out.println(userId+","+sex+","+college+","+major+","+phone+","+union+","+depart+","+type);
		//updateUser("15211110143",1,"���ݴ�ѧ","���","15158656338",3,3,2);
		DBUtil.updateUser(userId,sex.equals("��")?1:2,college,major,phone,3,3,2);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		writer.write("update success");
		writer.flush();
		return null;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getUnion() {
		return union;
	}

	public void setUnion(String union) {
		this.union = union;
	}

	public String getDepart() {
		return depart;
	}

	public void setDepart(String depart) {
		this.depart = depart;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
