package cn.eason.infoSystem.Action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import cn.eason.infoSystem.Util.DBUtil;
import net.sf.json.JSONArray;

public class DepartAction {

	private String departId;
	
	public String ministerList() throws IOException {
		Integer id = Integer.parseInt(departId);
		//��ѯ���ݿ�
		JSONArray json = DBUtil.selectMinisterList(id);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		writer.write(json.toString());
		writer.flush();
		return null;
	}

	public String getDepartId() {
		return departId;
	}

	public void setDepartId(String departId) {
		this.departId = departId;
	}
	
}
