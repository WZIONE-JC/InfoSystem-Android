package cn.eason.infoSystem.Util;

import java.util.List;

import cn.eason.infoSystem.Entity.Depart;
import cn.eason.infoSystem.Entity.Union;
import cn.eason.infoSystem.Entity.User;
import net.sf.json.JSONArray;

public class JsonUtil {
	public static JSONArray listToUnionJson(List<Union> list){
        JSONArray json = JSONArray.fromObject(list);     
        return json;
	}
	public static JSONArray listToDepartJson(List<Depart> list){
        JSONArray json = JSONArray.fromObject(list);     
        return json;
	}
	public static JSONArray listToUserJson(List<User> list){
        JSONArray json = JSONArray.fromObject(list);     
        return json;
	}
}
