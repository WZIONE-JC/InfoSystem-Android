package cn.eason.infoSystem.Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import cn.eason.infoSystem.Entity.Depart;
import cn.eason.infoSystem.Entity.Union;
import cn.eason.infoSystem.Entity.User;
import net.sf.json.JSONArray;


public class DBUtil {
	//����Mysql�����ݿ���������
	public static final String DBDRIVER = "com.mysql.jdbc.Driver";
	//����Mysql�����ݿ�����ӵ�ַ
	public static final String DBURL = "jdbc:mysql://localhost:3306/db_info_manage?useUnicode=true&characterEncoding=UTF-8";
	//����Mysql�����ݿ�������û���
	public static final String DBUSER = "root";
	//����Mysql�����ݿ����������
	public static final String DBPASS = "mysqladmin";
	//�������ݿ�����
	private static Connection conn=null;
	//���ݿ����
	private static Statement stmt=null;    
	
	public static void connect() {
		try{
			Class.forName(DBDRIVER);//������������
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			conn = DriverManager.getConnection(DBURL,DBUSER,DBPASS);
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public static void close() {
		try{
			stmt.close();		//�رղ���
			conn.close();		//�ر����ݿ�
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public static void executeSql(String sql) {
		connect();	
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			stmt.executeUpdate(sql);    //ִ�����ݿ���²���
		} catch (SQLException e) {
			//e.printStackTrace();
			rollback(conn);
		}
		close();
	}
	
	public static void rollback(Connection conn) {
		if(conn != null) {
			try {
				conn.rollback();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@SuppressWarnings("finally")
	public static JSONArray selectUnionList(){
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		List<Union> list = new ArrayList<Union>();
		JSONArray json = new JSONArray();
		String sql = "select * from t_union;";
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql);   
			ResultSetMetaData md = rs.getMetaData(); // ��ý�����ṹ��Ϣ,Ԫ����
			int columnCount = md.getColumnCount(); // �������
			while(rs.next()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    rowData.put(md.getColumnName(i), rs.getObject(i));
                }
                //System.out.println(rowData);
                Union union = MapUtil.parseMap2Object(rowData, Union.class);
                //System.out.println(union);
                list.add(union);
			}
			json = JsonUtil.listToUnionJson(list);
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return json;
		}
	}
	
	@SuppressWarnings("finally")
	public static JSONArray selectDepartList(String unionId){
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		List<Depart> list = new ArrayList<Depart>();
		JSONArray json = new JSONArray();
		String sql = "select * from t_depart where unionId='"+unionId+"';";
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql);   
			ResultSetMetaData md = rs.getMetaData(); // ��ý�����ṹ��Ϣ,Ԫ����
			int columnCount = md.getColumnCount(); // �������
			while(rs.next()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    rowData.put(md.getColumnName(i), rs.getObject(i));
                }
                //System.out.println(rowData);
                Depart depart = MapUtil.parseMap2Object(rowData, Depart.class);
                //System.out.println(union);
                list.add(depart);
			}
			json = JsonUtil.listToDepartJson(list);
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return json;
		}
	}
	
	@SuppressWarnings("finally")
	public static JSONArray selectMinisterList(Integer departId){
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		List<User> list = new ArrayList<User>();
		JSONArray json = new JSONArray();
		String sql = "select * from t_user where departId="+departId+";";
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql);   
			ResultSetMetaData md = rs.getMetaData(); // ��ý�����ṹ��Ϣ,Ԫ����
			int columnCount = md.getColumnCount(); // �������
			while(rs.next()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                	if(!md.getColumnName(i).equals("createDateTime"))
                		rowData.put(md.getColumnName(i), rs.getObject(i));
                }
                //System.out.println(rowData);
                User user = MapUtil.parseMap2Object(rowData, User.class);
                //System.out.println(union);
                list.add(user);
			}
			json = JsonUtil.listToUserJson(list);
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return json;
		}
	}
	
	@SuppressWarnings("finally")
	public static User selectUser(String sql) {
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		User user = null;
		if(sql.toLowerCase().contains("userid") && !sql.toLowerCase().contains("password")) {
			//@sql:select * from t_user where userId='15211110143';
			String userId = sql.substring(sql.indexOf("userId='")+8,sql.length()-2);
			user = new User(userId);
		}else if(sql.toLowerCase().contains("userid") && sql.toLowerCase().contains("password")){
			//@sql:select * from t_user where userId='15211110143' and password='123456';
			String userId = sql.substring(sql.toLowerCase().indexOf("userid='")+8,sql.toLowerCase().indexOf("' and"));
			String password = sql.substring(sql.toLowerCase().indexOf("password='")+10,sql.indexOf("';"));
			user = new User(userId,password);
		}
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql);    
			while(rs.next()) {
				user.setUserId(rs.getString("userId"));
				user.setName(rs.getString("name"));
				user.setUnionId(rs.getInt("unionId"));
				user.setDepartId(rs.getInt("departId"));
				user.setUserTypeId(rs.getInt("userTypeId"));
				user.setSex(rs.getInt("sex"));
				user.setPhone(rs.getString("phone"));
				user.setCollege(rs.getString("college"));
				user.setMajor(rs.getString("major"));
			}
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return user;
		}
	}
	
	@SuppressWarnings("finally")
	public static void updateUser(String userId,Integer sex,String college,String major,String phone,Integer union,Integer depart,Integer type){
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		//Update XX set ..=.. where ..=..
		//String sql = "update t_user set sex ="+sex+",college=\""+college+"\",major=\""+major+"\",phone=\""+phone+"\",union="+union+",depart="+depart+",type="+type+" where userId="+userId+";";
		String sql = "update t_user set sex="+sex+",college='"+college+"',major='"+major+"',phone='"+phone+"',unionId="+union+",departId="+depart+",userTypeId="+type+" where userId=15211110143;";
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			stmt.executeUpdate(sql);
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return;
		}
	}
	
	public static void main(String args[]) {
		//connect();
		//System.out.println(conn); //�����ʱ���Դ�ӡ��ʾ��������
//		JSONArray json = selectUnionList();
//		for(int i=0;i<json.size();i++) {
//			System.out.println(json.get(i));
//		}
		//System.out.println(selectUnionList());
		//System.out.println(selectUser("select * from t_user where userId='15211110143';"));
		System.out.println(selectUser("select * from t_user where userId='15211110143' and password='123456';"));
		//System.out.println(selectUser("select * from t_user where userId='15211110143' and password='1234567';"));
		//updateUser("15211110143",1,"���ݴ�ѧ","���","15158656338",3,3,2);//userId,sex,college,major,phone,union,depart,type
		
//		JSONArray json = selectMinisterList(1);
//		for(int i=0;i<json.size();i++) {
//			System.out.println(json.get(i));
//		}
	}
}
