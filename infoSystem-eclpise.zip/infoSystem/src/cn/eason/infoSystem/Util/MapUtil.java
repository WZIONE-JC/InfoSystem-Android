package cn.eason.infoSystem.Util;

import java.util.Map;

import com.alibaba.fastjson.JSONObject;

public class MapUtil {
	public static <T> T parseMap2Object(Map<String, Object> paramMap, Class<T> cls) {
		return JSONObject.parseObject(JSONObject.toJSONString(paramMap), cls);
	}
}
