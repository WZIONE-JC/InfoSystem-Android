package cn.eason.infoSystem.Entity;

public class Test {

	public static void main(String[] args) {
		String userInfo = "User [userId=15211110143, name=���, unionId=3, departId=3, userTypeId=2, sex=1, phone=15158656338, college=����ѧԺ, major=���]";
		String userId = userInfo.substring(userInfo.indexOf("userId=")+7,userInfo.indexOf(", name"));
		String name = userInfo.substring(userInfo.indexOf("name=")+5,userInfo.indexOf(", unionId"));
		String phone = userInfo.substring(userInfo.indexOf("phone=")+6,userInfo.indexOf(", college"));
		System.out.println(userId);
		System.out.println(name);
		System.out.println(phone);
	}
}
