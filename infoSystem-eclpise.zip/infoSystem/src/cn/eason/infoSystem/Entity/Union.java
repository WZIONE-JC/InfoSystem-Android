package cn.eason.infoSystem.Entity;

public class Union {
	private Integer id;
	private String name;
	private Integer belongId;//��֯����
	private String departSum;//��������
	private String ministerName;//��֯�ܸ�����
	private String remark;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getBelongId() {
		return belongId;
	}
	public void setBelongId(Integer belongId) {
		this.belongId = belongId;
	}
	public String getDepartSum() {
		return departSum;
	}
	public void setDepartSum(String departSum) {
		this.departSum = departSum;
	}
	public String getMinisterName() {
		return ministerName;
	}
	public void setMinisterName(String ministerName) {
		this.ministerName = ministerName;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "Union [id=" + id + ", name=" + name + ", belongId=" + belongId + ", departSum=" + departSum
				+ ", ministerName=" + ministerName + ", remark=" + remark + "]";
	}
}
