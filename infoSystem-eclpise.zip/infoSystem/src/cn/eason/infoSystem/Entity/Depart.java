package cn.eason.infoSystem.Entity;

/**
 * Created by Administrator on 2019/4/25 0025.
 */

public class Depart {
    private Integer id;
    private String name;
    private Integer unionId;
    private String teacherId;
    private String presidentId;
    private String ministerId;
    private Integer memberSum;
    private String featureActivities;
    private String remark;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getUnionId() {
		return unionId;
	}
	public void setUnionId(Integer unionId) {
		this.unionId = unionId;
	}
	public String getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}
	public String getPresidentId() {
		return presidentId;
	}
	public void setPresidentId(String presidentId) {
		this.presidentId = presidentId;
	}
	public String getMinisterId() {
		return ministerId;
	}
	public void setMinisterId(String ministerId) {
		this.ministerId = ministerId;
	}
	public Integer getMemberSum() {
		return memberSum;
	}
	public void setMemberSum(Integer memberSum) {
		this.memberSum = memberSum;
	}
	public String getFeatureActivities() {
		return featureActivities;
	}
	public void setFeatureActivities(String featureActivities) {
		this.featureActivities = featureActivities;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "Depart [id=" + id + ", name=" + name + ", unionId=" + unionId + ", teacherId=" + teacherId
				+ ", presidentId=" + presidentId + ", ministerId=" + ministerId + ", memberSum=" + memberSum
				+ ", featureActivities=" + featureActivities + ", remark=" + remark + "]";
	}
}
