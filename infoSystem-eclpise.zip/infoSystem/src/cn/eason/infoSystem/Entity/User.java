package cn.eason.infoSystem.Entity;

import java.util.Date;

public class User {
	private String userId;
    private String name;
    private String password;
    private Integer unionId;
    private Integer departId;
    private Integer userTypeId;
    private Integer sex;
    private String phone;
    private String major;
    private String college;
    private String remark;
    private Date createDateTime;
    
    
	public User() {
		super();
	}
	public User(String userId) {
		super();
		this.userId = userId;
	}
	public User(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getUnionId() {
		return unionId;
	}
	public void setUnionId(Integer unionId) {
		this.unionId = unionId;
	}
	public Integer getDepartId() {
		return departId;
	}
	public void setDepartId(Integer departId) {
		this.departId = departId;
	}
	public Integer getUserTypeId() {
		return userTypeId;
	}
	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}
	public Integer getSex() {
		return sex;
	}
	public void setSex(Integer sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", unionId=" + unionId
				+ ", departId=" + departId + ", userTypeId=" + userTypeId + ", sex=" + sex + ", phone=" + phone
				+ ", college=" + college + ", major=" + major + "]";
	}
}
